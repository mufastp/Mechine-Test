// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';

import '../../utils/colors.dart';

class AppTextFeild extends StatelessWidget {
  AppTextFeild(
      {super.key, required this.controller, this.label, this.hinttext,this.isobsecure,this.type});
  TextEditingController controller;
  String? label, hinttext;
  TextInputType? type;
  bool? isobsecure;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 79.90,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 6, left: 8),
            child: Text(
              label.toString(),
              style: const TextStyle(
                  color: kloginhead, fontSize: 16, fontWeight: FontWeight.w400),
            ),
          ),
          SizedBox(
            height: 50,
            child: TextFormField(
              obscureText:isobsecure?? false,
              controller: controller,
              keyboardType:type?? TextInputType.text,
              decoration: InputDecoration(
                  filled: true,
                  fillColor: ktextfeildfill.withOpacity(0.25),
                  hintText: hinttext,
                  hintStyle: TextStyle(
                      color: kblack.withOpacity(0.4),
                      fontWeight: FontWeight.w300,
                      fontSize: 14,
                      fontFamily: ''),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.53),
                    borderSide:
                        BorderSide(color: kblack.withOpacity(0.1), width: 0.85),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.53),
                    borderSide:
                        BorderSide(color: kblack.withOpacity(0.1), width: 0.85),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.53),
                    borderSide:
                        BorderSide(color: kblack.withOpacity(0.1), width: 0.85),
                  )),
            ),
          )
        ],
      ),
    );
  }
}
