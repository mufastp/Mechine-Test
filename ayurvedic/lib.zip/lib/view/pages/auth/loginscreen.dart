import 'package:ayurvedic/utils/extensions/space_ext.dart';
import 'package:ayurvedic/view/home/homescreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/colors.dart';
import '../../components/appbutton.dart';
import '../../components/apptext.dart';
import '../../components/apptextfeild.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});
  TextEditingController emailCtrl = TextEditingController(),
      passCtrl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 217,
                child: Stack(
                  children: [
                    Image.asset('assets/images/bg2.png'),
                    Center(child: SizedBox(
                      width: 80,
                      height: 84,
                      child: Image.asset('assets/images/logo.png',))),

                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
                child: Column(
                  children: [
                    AppText(text: 'Login Or Register To Book Your Appointments',size: 24,weight: FontWeight.w600,color: kloginhead,),
                    30.hBox,
                    Column(
                      children: [
                        AppTextFeild(
                          type: TextInputType.emailAddress,
                          controller: emailCtrl,
                          label: 'Email',
                          hinttext: 'Enter your email',
                        ),
                      ],
                    ),
                    20.hBox,
                    AppTextFeild(
                      isobsecure: true,
                      controller: passCtrl,
                      label: 'Password',
                      hinttext: 'Enter Password',
                    ),
                    30.hBox,
                    AppButton(onPressed: (){
                        Navigator.pushReplacement(context, CupertinoPageRoute(builder: (context) => HomePage(),));
                    },),
                    AppText(text: 'By creating or logging into an account you are agreeing ',size: 12,weight: FontWeight.w300,color: kblack,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       
                        AppText(text: 'with our ',size: 12,weight: FontWeight.w300,color: kblack,),
                        AppText(text: 'Terms and Conditions ',size: 12,weight: FontWeight.w500,color: kblue,),
                        AppText(text: 'and ',size: 12,weight: FontWeight.w300,color: kblack,),
                        AppText(text: ' Privacy Policy ',size: 12,weight: FontWeight.w500,color: kblue,),
                        AppText(text: '.',size: 12,weight: FontWeight.w300,color: kblack,),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}



