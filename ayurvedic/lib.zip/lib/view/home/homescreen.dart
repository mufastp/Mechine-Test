import 'dart:developer';

import 'package:ayurvedic/utils/extensions/space_ext.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../pages/auth/registerscreen.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size(0, 250),
          child: AppBar(
            actions: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                    width: 30, child: Image.asset("assets/images/bellicon.png")),
              ),
            ],
            // backgroundColor: Colors.blue,
            flexibleSpace: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
              children: [
                const SizedBox(
                  height: 130,
                ),
                Row(
                  children: [
                    const Expanded(
                      flex: 3,
                      child: SizedBox(
                          height: 50, child: CupertinoSearchTextField()),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      flex: 1,
                      child: SizedBox(
                        height: 50,
                        child: ElevatedButton(
                            style: ButtonStyle(
                              foregroundColor: const MaterialStatePropertyAll(Colors.white),
                                backgroundColor: MaterialStateProperty.all(
                                  const Color.fromRGBO(0, 104, 55, 1),
                                ),
                                shape: MaterialStateProperty.all<
                                        RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ))),
                            onPressed: () {},
                            child: const Text(
                              "Search",
                            )),
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Sort by :",
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(
                        width: 169,
                        child: OutlinedButton(
                            onPressed: () {}, child: const Text("data"))),
                  ],
                ),
                const Divider()
              ],
                              ),
                            ),
            ),
          )),
      body: ListView.builder(
        itemCount: 100,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.blueGrey[50],
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Text(
                          "$index.  ",
                          style: const TextStyle(fontSize: 18),
                        ),
                        const Expanded(
                          flex: 2,
                          child: Text("Vikram Singh",
                              style: TextStyle(fontSize: 18)),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(flex: 1, child: 5.wBox),
                        const Expanded(
                          flex: 15,
                          child: Text("Couple Combo Package (Rejuven...",
                              style: TextStyle(fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(flex: 1, child: 5.wBox),
                        Expanded(
                          flex: 15,
                          child: Row(
                            children: [
                              const Icon(
                                Icons.calendar_month_outlined,
                                color: Colors.red,
                                size: 18,
                              ),
                              const Text("02/02/2024",
                                  style: TextStyle(fontSize: 15)),
                              20.wBox,
                              const Icon(
                                Icons.person_2,
                                color: Colors.red,
                                size: 18,
                              ),
                              const Text("Jasim", style: TextStyle(fontSize: 15)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(
                    color: Colors.grey,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        const Text("View Booking details",
                            style: TextStyle(fontSize: 16)),
                        20.wBox,
                        const Icon(Icons.arrow_forward_ios_sharp)
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: SizedBox(
          height: 70,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    CupertinoPageRoute(
                      builder: (context) => const RegisterScreen(),
                    ));
                log("message");
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: const Color.fromRGBO(0, 104, 55, 1),
                ),
                child: const Center(
                    child: Text(
                  "Register Now",
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                      letterSpacing: 2),
                )),
              ),
            ),
          )),
    );
  }
}