import 'package:flutter/material.dart';

const kloginhead = Color(0xFF404040),
    kblack = Colors.black,
    ktextfeildfill = Color(0xFFD9D9D9),
    kblue = Color(0xff0028FC),
    kbtncolor = Color(0xff006837),
    ktransparent = Colors.transparent,
    kwhite = Colors.white;
